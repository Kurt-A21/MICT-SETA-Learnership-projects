
def register_endpoints(router):
    pass
