__author__ = 'dracks'

from django.conf.urls import include, url

# from team_passwords.api.resources import SiteResource

from .rest.views import SiteViewSet, GroupViewSet, GroupUserPermissionViewSet



urlpatterns = []
