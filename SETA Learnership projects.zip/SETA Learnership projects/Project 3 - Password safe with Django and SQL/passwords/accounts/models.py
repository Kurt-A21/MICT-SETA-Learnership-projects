from django.db import models
# If sometimes we need to change the base of the user model, we only need to change this, all the references affect to
# this file
from django.contrib.auth.models import User

# Create your models here.
