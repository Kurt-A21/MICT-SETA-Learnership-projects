# django_spellbee
Simple Webapp that corrects spellings of words/ sentences given. This webapp is created by using django and textblob libraries of python.
Django is a high level python framework that enables rapid webapp development.
Textblob is a python library that is used for natural language processing. correct() method from textblob library helps to return correct spelling of given word.
![image](https://user-images.githubusercontent.com/48251409/164650124-1c16f99d-61d8-4035-82f8-6f3edaef66fc.png)
![image](https://user-images.githubusercontent.com/48251409/164650255-efb945e0-d144-4a30-809e-e2a0eef35ec5.png)
![image](https://user-images.githubusercontent.com/48251409/164650327-c1b42b6f-2610-463b-adef-2a371ae79c90.png)

Similarly, we can even give an entire sentence at once and obtain correct spelling of each word in the sentence.

Thanks.
