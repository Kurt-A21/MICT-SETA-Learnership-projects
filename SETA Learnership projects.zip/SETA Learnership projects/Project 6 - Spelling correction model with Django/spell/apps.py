from django.apps import AppConfig


class SpellConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'spell'
