import numpy as np
from matplotlib import pyplot as plt
from location_variables import *
import seaborn as sns

#Plot for total deaths
sns.set()
plt.plot(world.date, world.total_deaths/10**6)
plt.plot(high_income_countries.date, high_income_countries.total_deaths/10**6)
plt.plot(upper_middle_income_countries.date, upper_middle_income_countries.total_deaths/10**6)
plt.plot(lower_middle_income_countries.date, lower_middle_income_countries.total_deaths/10**6)
plt.plot(europe.date, europe.total_deaths/10**6)
plt.plot(asia.date, asia.total_deaths/10**6)
plt.plot(south_america.date, south_america.total_deaths/10**6)
plt.plot(north_america.date, north_america.total_deaths/10**6)

plt.legend(["World", "High Income Countries", "Upper Middle Income Countries", 
            "Lower Middle Income Countries", "Europe", "Asia", "South America",
            "North America"])

plt.xlabel("Date")
plt.ylabel("Total Deaths(Million)")
plt.title("Total COVID-19 Deaths")
plt.show()

#numpy
print("\nNumpy Statistics\n")
print("-------------------------------------------------")

sum1 = np.sum(world.total_deaths)
print("\nThe sum of the total deaths worldwide: ", sum1, "\n")

product = np.prod(world.total_deaths)
print("The product of the total deaths worldwide: ", product, "\n")

median = np.mean(world.total_deaths)
print("The median of the total deaths worldwide: ", median, "\n")

varriant = np.var(world.total_deaths)
print("The varriant of the total deaths worldwide: ", varriant, "\n")

min_value = np.min(world.total_deaths)
print("The minimum value of the total deaths worldwide: ", min_value, "\n")

max_value = np.max(world.total_deaths)
print("The maximum value of the total deaths worldwide: ", max_value, "\n")