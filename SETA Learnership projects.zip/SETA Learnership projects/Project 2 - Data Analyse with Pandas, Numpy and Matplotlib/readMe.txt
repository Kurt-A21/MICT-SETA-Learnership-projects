Instructions:

1. Expand graph to see data properly

2. After running the data, close graph of specific analysis to see further numpy statistics in the terminal.

NB: Location_variable.py is the main python file.