import numpy as np
from matplotlib import pyplot as plt
from location_variables import *
import seaborn as sns

#Plot for total cases
sns.set()
plt.plot(world.date, world.total_cases/10**6)
plt.plot(high_income_countries.date, high_income_countries.total_cases/10**6)
plt.plot(upper_middle_income_countries.date, upper_middle_income_countries.total_cases/10**6)
plt.plot(lower_middle_income_countries.date, lower_middle_income_countries.total_cases/10**6)
plt.plot(europe.date, europe.total_cases/10**6)
plt.plot(asia.date, asia.total_cases/10**6)
plt.plot(south_america.date, south_america.total_cases/10**6)
plt.plot(north_america.date, north_america.total_cases/10**6)

plt.legend(["World", "High Income Countries", "Upper Middle Income Countries", 
            "Lower Middle Income Countries", "Europe", "Asia", "South America",
            "North America"])

plt.xlabel("Date")
plt.ylabel("Total Cases(Million)")
plt.title("Total COVID-19 Cases")

plt.tight_layout()
plt.show()

#numpy
print("\nNumpy Statistics\n")
print("-------------------------------------------------")

sum1 = np.sum(world.total_cases)
print("\nThe sum of the total cases worldwide: ", sum1, "\n")

product = np.prod(world.total_cases)
print("\nThe product of the total cases worldwide: ", product, "\n")

median = np.mean(world.total_cases)
print("The median of the total cases worldwide: ", median, "\n")

varriant = np.var(world.total_cases)
print("The varriant of the total cases worldwide: ", varriant, "\n")

min_value = np.min(world.total_cases)
print("The minimum value of the total cases worldwide: ", min_value, "\n")

max_value = np.max(world.total_cases)
print("The maximum value of the total cases worldwide: ", max_value, "\n")
