import pandas as pd
from pandas import *
from datetime import *

#Strip time
d_parser = lambda x: datetime.strptime(x, "%Y-%m-%d")
file_data = pd.read_csv("owid-covid-data.csv",na_values="-", parse_dates=["date"], date_parser=d_parser)

#Fill NaN with 0 
file_data.fillna(0,inplace=True)
file_data.head()

#location Variables
world = file_data[file_data.location == "World"]
high_income_countries = file_data[file_data.location == "High income"]
upper_middle_income_countries = file_data[file_data.location == "Upper middle income"]
lower_middle_income_countries = file_data[file_data.location == "Lower middle income"]
#Continent Variables
europe = file_data[file_data.continent == "Europe"]
asia = file_data[file_data.continent == "Asia"]
south_america = file_data[file_data.continent == "South America"]
north_america  = file_data[file_data.continent == "North America"]

